mvn clean package
$HADOOP_HOME/bin/hadoop jar target/mm.jar mm -conf config.xml data/test2/A data/test2/B results/test2/D
